<?php
	header("HTTP/1.0 501 Not Implemented");
?>
